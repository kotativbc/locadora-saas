import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Eye } from 'lucide-react';
import { api, ApiError } from '../api';
import { EmptyState } from '../components/EmptyState';
import { StatusBadge } from '../components/StatusBadge';
import { ChangeCompanyStatusForm, COMPANY_STATUS_LABELS, COMPANY_STATUS_VARIANT } from '../components/CompanyStatusControls';
import { useAuth } from '../auth/AuthContext';

interface Plan {
  id: string;
  name: string;
  maxVehicles: number | null;
  maxUsers: number | null;
  active: boolean;
}

interface Company {
  id: string;
  name: string;
  tradeName: string | null;
  cnpj: string | null;
  status: string;
  statusReason: string | null;
  planId: string | null;
  plan: Plan | null;
  createdAt: string;
  addressStreet: string | null;
  addressNumber: string | null;
  addressComplement: string | null;
  addressNeighborhood: string | null;
  addressCity: string | null;
  addressState: string | null;
  addressZipCode: string | null;
  contactEmail: string | null;
  privacyOfficerName: string | null;
}

interface Summary {
  company: Company;
  consumption: {
    users: number;
    vehicles: number;
    customers: number;
    contracts: number;
    activeContracts: number;
  };
}

interface StatusEvent {
  id: string;
  fromStatus: string | null;
  toStatus: string;
  reason: string | null;
  createdAt: string;
}

interface SupportUser {
  id: string;
  name: string;
  email: string;
  active: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  roles: { role: { code: string; name: string } }[];
}

export function CompanyDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { startImpersonation } = useAuth();
  const [enteringSupport, setEnteringSupport] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [history, setHistory] = useState<StatusEvent[]>([]);
  const [users, setUsers] = useState<SupportUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFormOpen, setStatusFormOpen] = useState(false);
  const [editFormOpen, setEditFormOpen] = useState(false);
  const [planFormOpen, setPlanFormOpen] = useState(false);
  const [availablePlans, setAvailablePlans] = useState<Plan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState('');
  const [savingPlan, setSavingPlan] = useState(false);
  const [savingUserId, setSavingUserId] = useState<string | null>(null);
  const [tempPassword, setTempPassword] = useState<{ email: string; password: string } | null>(null);

  async function load() {
    if (!id) return;
    setLoading(true);
    try {
      const [s, h, u] = await Promise.all([
        api.get<Summary>(`/companies/${id}/summary`),
        api.get<StatusEvent[]>(`/companies/${id}/status-history`),
        api.get<SupportUser[]>(`/companies/${id}/users`),
      ]);
      setSummary(s);
      setHistory(h);
      setUsers(u);
      setSelectedPlanId(s.company.planId ?? '');
      api.get<Plan[]>('/plans').then((all) => setAvailablePlans(all.filter((p) => p.active))).catch(() => {});
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao carregar dados da empresa.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleToggleUser(user: SupportUser) {
    if (!id) return;
    setSavingUserId(user.id);
    setError(null);
    try {
      await api.patch(`/companies/${id}/users/${user.id}/active`, { active: !user.active });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao atualizar usuário.');
    } finally {
      setSavingUserId(null);
    }
  }

  async function handleResetPassword(user: SupportUser) {
    if (!id) return;
    if (!confirm(`Redefinir a senha de ${user.name}? A senha atual dele para de funcionar imediatamente.`)) return;
    setSavingUserId(user.id);
    setError(null);
    try {
      const result = await api.post<{ tempPassword: string }>(`/companies/${id}/users/${user.id}/reset-password`);
      setTempPassword({ email: user.email, password: result.tempPassword });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao redefinir senha.');
    } finally {
      setSavingUserId(null);
    }
  }

  async function handleChangePlan() {
    if (!id) return;
    setSavingPlan(true);
    setError(null);
    try {
      await api.post(`/companies/${id}/plan`, { planId: selectedPlanId || undefined });
      setPlanFormOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao trocar o plano.');
    } finally {
      setSavingPlan(false);
    }
  }

  async function handleEnterSupportMode() {
    if (!id) return;
    setEnteringSupport(true);
    setError(null);
    try {
      await startImpersonation(id);
      navigate('/');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao entrar em modo suporte.');
    } finally {
      setEnteringSupport(false);
    }
  }

  if (loading) {
    return <p>Carregando...</p>;
  }

  if (!summary) {
    return (
      <div>
        {error && <div className="error-banner">{error}</div>}
        <Link to="/empresas" style={{ color: 'var(--rtv-teal-600)' }}>
          ← Voltar pra Empresas
        </Link>
      </div>
    );
  }

  const { company, consumption } = summary;

  return (
    <div>
      <Link
        to="/empresas"
        style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--rtv-ink-600)', fontSize: 13, marginBottom: 10, textDecoration: 'none' }}
      >
        <ArrowLeft size={14} /> Empresas
      </Link>

      <div className="page-header">
        <div>
          <h1>{company.name}</h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
            <StatusBadge label={COMPANY_STATUS_LABELS[company.status] ?? company.status} variant={COMPANY_STATUS_VARIANT[company.status] ?? 'neutral'} />
            {company.statusReason && <span style={{ fontSize: 12, color: 'var(--rtv-ink-400)' }}>{company.statusReason}</span>}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className="logout-btn"
            style={{ color: 'var(--rtv-navy-900)', borderColor: 'var(--rtv-line-strong)', display: 'inline-flex', alignItems: 'center', gap: 6 }}
            disabled={enteringSupport}
            onClick={handleEnterSupportMode}
          >
            <Eye size={14} /> {enteringSupport ? 'Entrando...' : 'Entrar como (somente leitura)'}
          </button>
          <button
            className="logout-btn"
            style={{ color: 'var(--rtv-navy-900)', borderColor: 'var(--rtv-line-strong)' }}
            onClick={() => setEditFormOpen((v) => !v)}
          >
            {editFormOpen ? 'Cancelar' : 'Editar dados'}
          </button>
          <button className="btn btn--accent" onClick={() => setStatusFormOpen((v) => !v)}>
            {statusFormOpen ? 'Cancelar' : 'Mudar estado'}
          </button>
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {editFormOpen && (
        <EditCompanyForm
          company={company}
          onSaved={() => {
            setEditFormOpen(false);
            load();
          }}
          onCancel={() => setEditFormOpen(false)}
        />
      )}

      {statusFormOpen && (
        <ChangeCompanyStatusForm
          companyId={company.id}
          companyName={company.name}
          currentStatus={company.status}
          onDone={() => {
            setStatusFormOpen(false);
            load();
          }}
          onCancel={() => setStatusFormOpen(false)}
        />
      )}

      <div className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--ink-muted)', marginBottom: 4 }}>Plano</div>
          <strong>{company.plan?.name ?? 'Sem plano (sem limite)'}</strong>
        </div>
        <button
          className="logout-btn"
          style={{ color: 'var(--rtv-navy-900)', borderColor: 'var(--rtv-line-strong)' }}
          onClick={() => setPlanFormOpen((v) => !v)}
        >
          {planFormOpen ? 'Cancelar' : 'Mudar plano'}
        </button>
      </div>

      {planFormOpen && (
        <div className="card">
          <div className="field" style={{ marginBottom: 10 }}>
            <label>Novo plano</label>
            <select value={selectedPlanId} onChange={(e) => setSelectedPlanId(e.target.value)}>
              <option value="">Sem plano (sem limite)</option>
              {availablePlans.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <button className="btn" disabled={savingPlan} onClick={handleChangePlan}>
            {savingPlan ? 'Salvando...' : 'Confirmar plano'}
          </button>
        </div>
      )}

      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-card__label">Usuários {company.plan?.maxUsers ? `(limite: ${company.plan.maxUsers})` : ''}</div>
          <div
            className="kpi-card__value"
            style={company.plan?.maxUsers && consumption.users >= company.plan.maxUsers ? { color: 'var(--rtv-danger)' } : undefined}
          >
            {consumption.users}
            {company.plan?.maxUsers ? ` / ${company.plan.maxUsers}` : ''}
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-card__label">Veículos {company.plan?.maxVehicles ? `(limite: ${company.plan.maxVehicles})` : ''}</div>
          <div
            className="kpi-card__value"
            style={company.plan?.maxVehicles && consumption.vehicles >= company.plan.maxVehicles ? { color: 'var(--rtv-danger)' } : undefined}
          >
            {consumption.vehicles}
            {company.plan?.maxVehicles ? ` / ${company.plan.maxVehicles}` : ''}
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-card__label">Clientes</div>
          <div className="kpi-card__value">{consumption.customers}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-card__label">Contratos (ativos / total)</div>
          <div className="kpi-card__value">
            {consumption.activeContracts} / {consumption.contracts}
          </div>
        </div>
      </div>

      {tempPassword && (
        <div className="card" style={{ borderColor: 'var(--rtv-amber-500)' }}>
          <strong>Senha redefinida para {tempPassword.email}</strong>
          <p style={{ fontSize: 13, color: 'var(--ink-muted)' }}>
            Copie e repasse pra pessoa por um canal seguro — essa senha só aparece aqui uma vez, o sistema não guarda
            o texto puro.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <input readOnly value={tempPassword.password} style={{ flex: 1, padding: 8, fontFamily: 'var(--font-mono)', fontSize: 14 }} />
          </div>
          <button
            className="logout-btn"
            style={{ marginTop: 10, color: 'var(--ink-muted)', borderColor: 'var(--border)' }}
            onClick={() => setTempPassword(null)}
          >
            Fechar
          </button>
        </div>
      )}

      <div className="card">
        <strong style={{ display: 'block', marginBottom: 10 }}>Usuários</strong>
        {users.length === 0 ? (
          <EmptyState title="Nenhum usuário nesta empresa" />
        ) : (
          <table>
            <thead>
              <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Papel</th>
                <th>Status</th>
                <th>Último acesso</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.roles.map((r) => r.role.name).join(', ')}</td>
                  <td>
                    <StatusBadge label={u.active ? 'Ativo' : 'Inativo'} variant={u.active ? 'success' : 'neutral'} />
                  </td>
                  <td>{u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString('pt-BR') : 'Nunca'}</td>
                  <td style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <button
                      className="logout-btn"
                      style={{ color: 'var(--rtv-navy-900)', borderColor: 'var(--rtv-line-strong)' }}
                      disabled={savingUserId === u.id}
                      onClick={() => handleToggleUser(u)}
                    >
                      {u.active ? 'Desativar' : 'Reativar'}
                    </button>
                    <button
                      className="logout-btn"
                      style={{ color: 'var(--rtv-navy-900)', borderColor: 'var(--rtv-line-strong)' }}
                      disabled={savingUserId === u.id}
                      onClick={() => handleResetPassword(u)}
                    >
                      Redefinir senha
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <strong style={{ display: 'block', marginBottom: 10 }}>Histórico de estado</strong>
        {history.length === 0 ? (
          <p style={{ margin: 0, fontSize: 13, color: 'var(--ink-muted)' }}>Sem mudanças de estado registradas.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Quando</th>
                <th>De</th>
                <th>Para</th>
                <th>Motivo</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{new Date(h.createdAt).toLocaleString('pt-BR')}</td>
                  <td>{h.fromStatus ? COMPANY_STATUS_LABELS[h.fromStatus] ?? h.fromStatus : '—'}</td>
                  <td>{COMPANY_STATUS_LABELS[h.toStatus] ?? h.toStatus}</td>
                  <td>{h.reason ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {company.status === 'archived' && (
        <DangerZone company={company} onDeleted={() => navigate('/empresas')} />
      )}
    </div>
  );
}

function EditCompanyForm({
  company,
  onSaved,
  onCancel,
}: {
  company: Company;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(company.name);
  const [tradeName, setTradeName] = useState(company.tradeName ?? '');
  const [cnpj, setCnpj] = useState(company.cnpj ?? '');
  const [addressStreet, setAddressStreet] = useState(company.addressStreet ?? '');
  const [addressNumber, setAddressNumber] = useState(company.addressNumber ?? '');
  const [addressComplement, setAddressComplement] = useState(company.addressComplement ?? '');
  const [addressNeighborhood, setAddressNeighborhood] = useState(company.addressNeighborhood ?? '');
  const [addressCity, setAddressCity] = useState(company.addressCity ?? '');
  const [addressState, setAddressState] = useState(company.addressState ?? '');
  const [addressZipCode, setAddressZipCode] = useState(company.addressZipCode ?? '');
  const [contactEmail, setContactEmail] = useState(company.contactEmail ?? '');
  const [privacyOfficerName, setPrivacyOfficerName] = useState(company.privacyOfficerName ?? '');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await api.patch(`/companies/${company.id}`, {
        name,
        tradeName: tradeName || undefined,
        cnpj: cnpj || undefined,
        addressStreet: addressStreet || undefined,
        addressNumber: addressNumber || undefined,
        addressComplement: addressComplement || undefined,
        addressNeighborhood: addressNeighborhood || undefined,
        addressCity: addressCity || undefined,
        addressState: addressState || undefined,
        addressZipCode: addressZipCode || undefined,
        contactEmail: contactEmail || undefined,
        privacyOfficerName: privacyOfficerName || undefined,
      });
      onSaved();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao salvar.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h3 style={{ marginTop: 0 }}>Editar dados — {company.name}</h3>
      {error && <div className="error-banner">{error}</div>}

      <div className="field-group">
        <div className="field-group__label">Identificação</div>
        <div className="field">
          <label>Razão social</label>
          <input required value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="field">
          <label>Nome fantasia</label>
          <input value={tradeName} onChange={(e) => setTradeName(e.target.value)} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>CNPJ</label>
          <input value={cnpj} onChange={(e) => setCnpj(e.target.value)} />
        </div>
      </div>

      <div className="field-group">
        <div className="field-group__label">Endereço</div>
        <div className="field">
          <label>Rua/Avenida</label>
          <input value={addressStreet} onChange={(e) => setAddressStreet(e.target.value)} />
        </div>
        <div className="field">
          <label>Número</label>
          <input value={addressNumber} onChange={(e) => setAddressNumber(e.target.value)} />
        </div>
        <div className="field">
          <label>Complemento</label>
          <input value={addressComplement} onChange={(e) => setAddressComplement(e.target.value)} />
        </div>
        <div className="field">
          <label>Bairro</label>
          <input value={addressNeighborhood} onChange={(e) => setAddressNeighborhood(e.target.value)} />
        </div>
        <div className="field">
          <label>Cidade</label>
          <input value={addressCity} onChange={(e) => setAddressCity(e.target.value)} />
        </div>
        <div className="field">
          <label>Estado (sigla)</label>
          <input value={addressState} maxLength={2} onChange={(e) => setAddressState(e.target.value.toUpperCase())} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>CEP</label>
          <input value={addressZipCode} onChange={(e) => setAddressZipCode(e.target.value)} />
        </div>
      </div>

      <div className="field-group">
        <div className="field-group__label">Contato / privacidade</div>
        <div className="field">
          <label>E-mail de contato</label>
          <input type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <label>Encarregado (opcional)</label>
          <input value={privacyOfficerName} onChange={(e) => setPrivacyOfficerName(e.target.value)} />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <button className="btn" type="submit" disabled={saving}>
          {saving ? 'Salvando...' : 'Salvar alterações'}
        </button>
        <button type="button" className="logout-btn" style={{ color: 'var(--ink-muted)', borderColor: 'var(--border)' }} onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
}

function DangerZone({ company, onDeleted }: { company: Company; onDeleted: () => void }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmName, setConfirmName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    setError(null);
    setDeleting(true);
    try {
      await api.delete(`/companies/${company.id}`, { confirmName });
      onDeleted();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Erro ao excluir.');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="card" style={{ borderColor: 'var(--rtv-danger)' }}>
      <strong style={{ color: 'var(--rtv-danger)', display: 'block', marginBottom: 4 }}>Zona de risco</strong>
      <p style={{ fontSize: 13, color: 'var(--ink-muted)', marginTop: 0, marginBottom: 14 }}>
        Excluir permanentemente apaga esta empresa e tudo que pertence a ela — usuários, veículos, clientes,
        contratos, financeiro, documentos. Não tem como desfazer. Só é possível porque esta empresa já está
        "Arquivada"; o histórico de auditoria da exclusão em si fica registrado, mas não a empresa.
      </p>

      {error && <div className="error-banner">{error}</div>}

      {!confirmOpen ? (
        <button
          className="logout-btn"
          style={{ color: 'var(--rtv-danger)', borderColor: 'var(--rtv-danger)' }}
          onClick={() => setConfirmOpen(true)}
        >
          Excluir permanentemente
        </button>
      ) : (
        <div>
          <div className="field">
            <label>
              Digite exatamente <strong>{company.name}</strong> pra confirmar
            </label>
            <input value={confirmName} onChange={(e) => setConfirmName(e.target.value)} autoFocus />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              className="btn"
              style={{ background: 'var(--rtv-danger)' }}
              disabled={confirmName !== company.name || deleting}
              onClick={handleDelete}
            >
              {deleting ? 'Excluindo...' : 'Confirmar exclusão definitiva'}
            </button>
            <button
              type="button"
              className="logout-btn"
              style={{ color: 'var(--ink-muted)', borderColor: 'var(--border)' }}
              onClick={() => {
                setConfirmOpen(false);
                setConfirmName('');
              }}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
